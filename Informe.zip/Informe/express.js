const express = require('express');
  const app = express();
  
  app.get('/nosotros', (req, res) => {
    res.send('Hola con ExpressPagina de nosotros');
  });
  app.get('/contactenos', (req, res) => {
    res.send('Página de contacto');
  });

  app.get('/usuario/:id', (req, res) => {
    res.send(`Usuario ID: ${req.params.id}`);
  });
  
  app.listen(3000, () => console.log('Servidor Express'));